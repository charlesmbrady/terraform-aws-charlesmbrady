"""
AgentCore Runtime - Ultra-Minimal Working Version
Only uses guaranteed pre-installed packages
"""

import os
import json

print("[startup] Python runtime started")

# Try importing bedrock_agentcore - confirmed to work from previous test
from bedrock_agentcore.runtime import BedrockAgentCoreApp
print("[startup] ✓ bedrock_agentcore imported")

app = BedrockAgentCoreApp()
print("[startup] ✓ App initialized")

# Read config
MODEL_ID = os.environ.get("FOUNDATION_MODEL", "anthropic.claude-3-5-sonnet-20240620-v1:0")
AGENT_INSTRUCTION = os.environ.get("AGENT_INSTRUCTION", "You are a helpful assistant.")
RAG_BUCKET = os.environ.get("RAG_BUCKET", "")

print(f"[startup] Config loaded - Model: {MODEL_ID[:50]}...")


@app.entrypoint
def invoke(payload, context=None):
    """
    Minimal working handler - synchronous version
    """
    print(f"[invoke] Function called with payload type: {type(payload)}")
    print(f"[invoke] Payload: {payload}")
    
    try:
        user_input = payload.get("input") or payload.get("prompt", "") if isinstance(payload, dict) else str(payload)
        
        print(f"[invoke] Extracted input: {user_input[:100] if user_input else 'empty'}")
        
        # For now, just echo back with config info
        response = {
            "message": f"AgentCore runtime is working! You said: {user_input}",
            "model": MODEL_ID,
            "instruction": AGENT_INSTRUCTION[:100],
            "status": "ready_for_strands_integration"
        }
        
        result = json.dumps(response, indent=2)
        print(f"[invoke] Returning response ({len(result)} chars)")
        return result
        
    except Exception as e:
        import traceback
        error_msg = f"Error in invoke: {str(e)}"
        print(f"[invoke-error] {error_msg}")
        print(f"[invoke-error] Traceback:\n{traceback.format_exc()}")
        return json.dumps({"error": error_msg, "traceback": traceback.format_exc()})


if __name__ == "__main__":
    print("[startup] Starting server")
    app.run()
